import xbmcaddon
import xbmcgui
import os
import subprocess 

def get_process_id(name):
    child = subprocess.Popen(['pgrep', '-f', name], stdout=subprocess.PIPE, shell=False)
    response = child.communicate()[0]
    return [int(pid) for pid in response.split()]
 
addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')

#os.system('systemctl stop service.hyperion.ng.service 2>/dev/null')

try:
    pid = get_process_id("hyperion")[0]
    os.system('systemctl stop service.hyperion.ng.service 2>/dev/null')
    line1 = "Hyperion was running. Stopping..." 
except:
    os.system('systemctl start service.hyperion.ng.service 2>/dev/null')    
    line1 = "Hyperion was not running. Starting..." 

xbmcgui.Dialog().ok(addonname, line1)
